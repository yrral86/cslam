﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kinematics
{
    public static class Constants
    {
        public static readonly int TRACK_WIDTH = 64;

        public static readonly int WHEEL_BASE = 59;

    }
}
