﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using lunabotics.Configuration;

namespace lunabotics.RCU.Models
{
    public class Kinematics
    {
        public static double MaximumWheelVelocity = 2.827; // rad/s
        public static double MaximumRotationalVelocity = 1.713; // rad/s
        public static double MaximumTranslationalVelocity = 0.557; // m/s
        public static double WheelRadius = 19.65; // cm
        public static double WheelTrack = 65.0; // cm

        public static Dictionary<Devices, int> GetWheelStates(double translationalVelocity, double rotationalVelocity)
        {
            // Calculate wheel angular velocities
            double omegaLeft = (translationalVelocity - ((WheelTrack / 2.0) * rotationalVelocity)) / WheelTrack;
            double omegaRight = (translationalVelocity + ((WheelTrack / 2.0) * rotationalVelocity)) / WheelTrack;

            // Set output
            Dictionary<Devices, int> output = new Dictionary<Devices, int>();
            output[Devices.FrontLeftWheel] = (int)((omegaLeft / MaximumWheelVelocity) * 1000.0d);
            output[Devices.RearLeftWheel] = (int)((omegaLeft / MaximumWheelVelocity) * 1000.0d);
            output[Devices.FrontRightWheel] = (int)((omegaRight / MaximumWheelVelocity) * 1000.0d);
            output[Devices.RearRightWheel] = (int)((omegaRight / MaximumWheelVelocity) * 1000.0d);

            return output;
        }

        public static double GetRotationalVelocity(short command)
        {
            return ((double)command / 1000.0d) * MaximumRotationalVelocity;
        }

        public static double GetTranslationalVelocity(short command)
        {
            return ((double)command / 1000.0d) * MaximumTranslationalVelocity;
        }
    }
}
