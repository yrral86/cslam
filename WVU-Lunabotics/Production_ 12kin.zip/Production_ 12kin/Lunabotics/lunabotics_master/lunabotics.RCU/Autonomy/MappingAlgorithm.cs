﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lunabotics.RCU.Autonomy
{
    public class MappingAlgorithm
    {
        #region Fields
        private static double servoPosition;
        #endregion

        #region Constructor

        #endregion

        #region Methods
        public void Update(double elapsedTime)
        {
            // Goto 0deg
            // Ramp to 
        }
        #endregion
    }
}
