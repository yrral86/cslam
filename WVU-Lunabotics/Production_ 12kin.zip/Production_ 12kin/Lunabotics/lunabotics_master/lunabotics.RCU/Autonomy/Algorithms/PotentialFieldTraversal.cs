﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace lunabotics.RCU.Autonomy.Algorithms
{
    public class PotentialFieldTraversal
    {
        #region Fields
        
        #endregion

        #region Constructors
        public PotentialFieldTraversal()
        {

        }
        #endregion

        #region Methods
        public void Update(Robot robot, Stopwatch stopwatch)
        {

        }
        #endregion
    }
}
