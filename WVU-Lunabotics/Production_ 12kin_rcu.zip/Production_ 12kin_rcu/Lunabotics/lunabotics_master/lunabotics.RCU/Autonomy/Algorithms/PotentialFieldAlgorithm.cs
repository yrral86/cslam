﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lunabotics.RCU.Autonomy.Algorithms
{
    public class PotentialFieldAlgorithm
    {
        #region Fields
        
        #endregion

        #region Constructor
        public PotentialFieldAlgorithm()
        {

        }
        #endregion

        #region Methods

        #endregion
    }
}
