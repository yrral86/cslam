﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace lunabotics.RCU.Autonomy
{
    public class MiningAlgorithm
    {
        #region Fields
        private Stopwatch stopwatch;
        #endregion

        #region Constructor
        public MiningAlgorithm(Stopwatch stopwatch)
        {

        }
        #endregion

        #region Methods
        public void Update()
        {
            // 
        }
        #endregion

        #region Properties
        
        #endregion
    }
}
