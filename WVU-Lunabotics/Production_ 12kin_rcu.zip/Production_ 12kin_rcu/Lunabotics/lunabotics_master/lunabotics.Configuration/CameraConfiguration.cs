﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lunabotics.Configuration
{
    public class CameraConfiguration
    {
        public string DeviceName;
        public int RCU_To_OCU_Framerate;
        public int JPEGQuality;
        public int SendPort;
    }
}
