﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lunabotics.Configuration
{
    [Serializable]
    public enum PhidgetServoChannel
    {
        Channel0 = 0,
        Channel1,
        Channel2,
        Channel3
    }
}
