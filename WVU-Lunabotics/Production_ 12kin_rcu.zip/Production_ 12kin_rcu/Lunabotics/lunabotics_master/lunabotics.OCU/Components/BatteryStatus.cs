﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace lunabotics.OCU.Components
{
    public enum BatteryStatus
    {
        Good,
        Ok,
        Critical,
        Unknown
    }
}
